﻿
namespace WholeSaleManagementSystem
{
    partial class Customer_Edit_Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customer_Edit_Profile));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dobErr = new System.Windows.Forms.Label();
            this.dobDatePicker = new System.Windows.Forms.DateTimePicker();
            this.lastNameErr = new System.Windows.Forms.Label();
            this.lastName_textBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.ID_label = new System.Windows.Forms.Label();
            this.phoneErr = new System.Windows.Forms.Label();
            this.emailErr = new System.Windows.Forms.Label();
            this.firstNameErr = new System.Windows.Forms.Label();
            this.phone_textbox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.email_textbox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.Logo = new System.Windows.Forms.Label();
            this.EditButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.firstName_textbox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.LogInFormEllips = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.Exit = new Bunifu.UI.WinForms.BunifuImageButton();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.dobErr);
            this.panel1.Controls.Add(this.dobDatePicker);
            this.panel1.Controls.Add(this.lastNameErr);
            this.panel1.Controls.Add(this.lastName_textBox);
            this.panel1.Controls.Add(this.ID_label);
            this.panel1.Controls.Add(this.phoneErr);
            this.panel1.Controls.Add(this.emailErr);
            this.panel1.Controls.Add(this.firstNameErr);
            this.panel1.Controls.Add(this.phone_textbox);
            this.panel1.Controls.Add(this.email_textbox);
            this.panel1.Controls.Add(this.Logo);
            this.panel1.Controls.Add(this.EditButton);
            this.panel1.Controls.Add(this.firstName_textbox);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(10, 10);
            this.panel1.Margin = new System.Windows.Forms.Padding(10);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(15);
            this.panel1.Size = new System.Drawing.Size(419, 448);
            this.panel1.TabIndex = 1;
            // 
            // dobErr
            // 
            this.dobErr.AutoSize = true;
            this.dobErr.ForeColor = System.Drawing.Color.Red;
            this.dobErr.Location = new System.Drawing.Point(116, 284);
            this.dobErr.Name = "dobErr";
            this.dobErr.Size = new System.Drawing.Size(0, 13);
            this.dobErr.TabIndex = 23;
            // 
            // dobDatePicker
            // 
            this.dobDatePicker.CalendarFont = new System.Drawing.Font("Century Gothic", 9.75F);
            this.dobDatePicker.CalendarForeColor = System.Drawing.Color.DarkMagenta;
            this.dobDatePicker.Checked = false;
            this.dobDatePicker.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dobDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dobDatePicker.Location = new System.Drawing.Point(98, 258);
            this.dobDatePicker.Name = "dobDatePicker";
            this.dobDatePicker.Size = new System.Drawing.Size(234, 23);
            this.dobDatePicker.TabIndex = 4;
            this.dobDatePicker.Value = new System.DateTime(2022, 12, 30, 0, 0, 0, 0);
            this.dobDatePicker.CloseUp += new System.EventHandler(this.dobDatePicker_CloseUp);
            this.dobDatePicker.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dobDatePicker_KeyPress);
            // 
            // lastNameErr
            // 
            this.lastNameErr.AutoSize = true;
            this.lastNameErr.ForeColor = System.Drawing.Color.Red;
            this.lastNameErr.Location = new System.Drawing.Point(116, 142);
            this.lastNameErr.Name = "lastNameErr";
            this.lastNameErr.Size = new System.Drawing.Size(0, 13);
            this.lastNameErr.TabIndex = 21;
            // 
            // lastName_textBox
            // 
            this.lastName_textBox.AcceptsReturn = false;
            this.lastName_textBox.AcceptsTab = false;
            this.lastName_textBox.AnimationSpeed = 200;
            this.lastName_textBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.lastName_textBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.lastName_textBox.BackColor = System.Drawing.Color.White;
            this.lastName_textBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("lastName_textBox.BackgroundImage")));
            this.lastName_textBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.lastName_textBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.lastName_textBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.lastName_textBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.lastName_textBox.BorderRadius = 10;
            this.lastName_textBox.BorderThickness = 1;
            this.lastName_textBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.lastName_textBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.lastName_textBox.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastName_textBox.DefaultText = "";
            this.lastName_textBox.FillColor = System.Drawing.Color.White;
            this.lastName_textBox.ForeColor = System.Drawing.Color.DarkMagenta;
            this.lastName_textBox.HideSelection = true;
            this.lastName_textBox.IconLeft = null;
            this.lastName_textBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.lastName_textBox.IconPadding = 10;
            this.lastName_textBox.IconRight = null;
            this.lastName_textBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.lastName_textBox.Lines = new string[0];
            this.lastName_textBox.Location = new System.Drawing.Point(98, 108);
            this.lastName_textBox.MaxLength = 32767;
            this.lastName_textBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.lastName_textBox.Modified = false;
            this.lastName_textBox.Multiline = false;
            this.lastName_textBox.Name = "lastName_textBox";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.lastName_textBox.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.lastName_textBox.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.lastName_textBox.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.DarkMagenta;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.lastName_textBox.OnIdleState = stateProperties4;
            this.lastName_textBox.Padding = new System.Windows.Forms.Padding(3);
            this.lastName_textBox.PasswordChar = '\0';
            this.lastName_textBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.lastName_textBox.PlaceholderText = "Enter Last Name";
            this.lastName_textBox.ReadOnly = false;
            this.lastName_textBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.lastName_textBox.SelectedText = "";
            this.lastName_textBox.SelectionLength = 0;
            this.lastName_textBox.SelectionStart = 0;
            this.lastName_textBox.ShortcutsEnabled = true;
            this.lastName_textBox.Size = new System.Drawing.Size(234, 31);
            this.lastName_textBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.lastName_textBox.TabIndex = 1;
            this.lastName_textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.lastName_textBox.TextMarginBottom = 0;
            this.lastName_textBox.TextMarginLeft = 3;
            this.lastName_textBox.TextMarginTop = 0;
            this.lastName_textBox.TextPlaceholder = "Enter Last Name";
            this.lastName_textBox.UseSystemPasswordChar = false;
            this.lastName_textBox.WordWrap = true;
            this.lastName_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lastName_textBox_KeyDown);
            // 
            // ID_label
            // 
            this.ID_label.AutoSize = true;
            this.ID_label.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.ID_label.ForeColor = System.Drawing.Color.DarkMagenta;
            this.ID_label.Location = new System.Drawing.Point(142, 24);
            this.ID_label.Name = "ID_label";
            this.ID_label.Size = new System.Drawing.Size(21, 23);
            this.ID_label.TabIndex = 14;
            this.ID_label.Text = "?";
            // 
            // phoneErr
            // 
            this.phoneErr.AutoSize = true;
            this.phoneErr.ForeColor = System.Drawing.Color.Red;
            this.phoneErr.Location = new System.Drawing.Point(115, 235);
            this.phoneErr.Name = "phoneErr";
            this.phoneErr.Size = new System.Drawing.Size(0, 13);
            this.phoneErr.TabIndex = 13;
            // 
            // emailErr
            // 
            this.emailErr.AutoSize = true;
            this.emailErr.ForeColor = System.Drawing.Color.Red;
            this.emailErr.Location = new System.Drawing.Point(115, 188);
            this.emailErr.Name = "emailErr";
            this.emailErr.Size = new System.Drawing.Size(0, 13);
            this.emailErr.TabIndex = 12;
            // 
            // firstNameErr
            // 
            this.firstNameErr.AutoSize = true;
            this.firstNameErr.ForeColor = System.Drawing.Color.Red;
            this.firstNameErr.Location = new System.Drawing.Point(115, 92);
            this.firstNameErr.Name = "firstNameErr";
            this.firstNameErr.Size = new System.Drawing.Size(0, 13);
            this.firstNameErr.TabIndex = 11;
            // 
            // phone_textbox
            // 
            this.phone_textbox.AcceptsReturn = false;
            this.phone_textbox.AcceptsTab = false;
            this.phone_textbox.AnimationSpeed = 200;
            this.phone_textbox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.phone_textbox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.phone_textbox.BackColor = System.Drawing.Color.White;
            this.phone_textbox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("phone_textbox.BackgroundImage")));
            this.phone_textbox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.phone_textbox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.phone_textbox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.phone_textbox.BorderColorIdle = System.Drawing.Color.Silver;
            this.phone_textbox.BorderRadius = 10;
            this.phone_textbox.BorderThickness = 1;
            this.phone_textbox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.phone_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.phone_textbox.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone_textbox.DefaultText = "";
            this.phone_textbox.FillColor = System.Drawing.Color.White;
            this.phone_textbox.ForeColor = System.Drawing.Color.DarkMagenta;
            this.phone_textbox.HideSelection = true;
            this.phone_textbox.IconLeft = null;
            this.phone_textbox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.phone_textbox.IconPadding = 10;
            this.phone_textbox.IconRight = null;
            this.phone_textbox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.phone_textbox.Lines = new string[0];
            this.phone_textbox.Location = new System.Drawing.Point(98, 201);
            this.phone_textbox.MaxLength = 32767;
            this.phone_textbox.MinimumSize = new System.Drawing.Size(1, 1);
            this.phone_textbox.Modified = false;
            this.phone_textbox.Multiline = false;
            this.phone_textbox.Name = "phone_textbox";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.phone_textbox.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.phone_textbox.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.phone_textbox.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.DarkMagenta;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.phone_textbox.OnIdleState = stateProperties8;
            this.phone_textbox.Padding = new System.Windows.Forms.Padding(3);
            this.phone_textbox.PasswordChar = '\0';
            this.phone_textbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.phone_textbox.PlaceholderText = "Enter Phone";
            this.phone_textbox.ReadOnly = false;
            this.phone_textbox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.phone_textbox.SelectedText = "";
            this.phone_textbox.SelectionLength = 0;
            this.phone_textbox.SelectionStart = 0;
            this.phone_textbox.ShortcutsEnabled = true;
            this.phone_textbox.Size = new System.Drawing.Size(234, 31);
            this.phone_textbox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.phone_textbox.TabIndex = 3;
            this.phone_textbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.phone_textbox.TextMarginBottom = 0;
            this.phone_textbox.TextMarginLeft = 3;
            this.phone_textbox.TextMarginTop = 0;
            this.phone_textbox.TextPlaceholder = "Enter Phone";
            this.phone_textbox.UseSystemPasswordChar = false;
            this.phone_textbox.WordWrap = true;
            this.phone_textbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.phone_textbox_KeyDown);
            // 
            // email_textbox
            // 
            this.email_textbox.AcceptsReturn = false;
            this.email_textbox.AcceptsTab = false;
            this.email_textbox.AnimationSpeed = 200;
            this.email_textbox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.email_textbox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.email_textbox.BackColor = System.Drawing.Color.White;
            this.email_textbox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("email_textbox.BackgroundImage")));
            this.email_textbox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.email_textbox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.email_textbox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.email_textbox.BorderColorIdle = System.Drawing.Color.Silver;
            this.email_textbox.BorderRadius = 10;
            this.email_textbox.BorderThickness = 1;
            this.email_textbox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.email_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.email_textbox.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email_textbox.DefaultText = "";
            this.email_textbox.FillColor = System.Drawing.Color.White;
            this.email_textbox.ForeColor = System.Drawing.Color.DarkMagenta;
            this.email_textbox.HideSelection = true;
            this.email_textbox.IconLeft = null;
            this.email_textbox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.email_textbox.IconPadding = 10;
            this.email_textbox.IconRight = null;
            this.email_textbox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.email_textbox.Lines = new string[0];
            this.email_textbox.Location = new System.Drawing.Point(98, 154);
            this.email_textbox.MaxLength = 32767;
            this.email_textbox.MinimumSize = new System.Drawing.Size(1, 1);
            this.email_textbox.Modified = false;
            this.email_textbox.Multiline = false;
            this.email_textbox.Name = "email_textbox";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.email_textbox.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.email_textbox.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.email_textbox.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.DarkMagenta;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.email_textbox.OnIdleState = stateProperties12;
            this.email_textbox.Padding = new System.Windows.Forms.Padding(3);
            this.email_textbox.PasswordChar = '\0';
            this.email_textbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.email_textbox.PlaceholderText = "Enter Email";
            this.email_textbox.ReadOnly = false;
            this.email_textbox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.email_textbox.SelectedText = "";
            this.email_textbox.SelectionLength = 0;
            this.email_textbox.SelectionStart = 0;
            this.email_textbox.ShortcutsEnabled = true;
            this.email_textbox.Size = new System.Drawing.Size(234, 31);
            this.email_textbox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.email_textbox.TabIndex = 2;
            this.email_textbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.email_textbox.TextMarginBottom = 0;
            this.email_textbox.TextMarginLeft = 3;
            this.email_textbox.TextMarginTop = 0;
            this.email_textbox.TextPlaceholder = "Enter Email";
            this.email_textbox.UseSystemPasswordChar = false;
            this.email_textbox.WordWrap = true;
            this.email_textbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.email_textbox_KeyDown);
            // 
            // Logo
            // 
            this.Logo.AutoSize = true;
            this.Logo.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.Logo.ForeColor = System.Drawing.Color.DarkMagenta;
            this.Logo.Location = new System.Drawing.Point(99, 24);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(33, 23);
            this.Logo.TabIndex = 10;
            this.Logo.Text = "ID:";
            // 
            // EditButton
            // 
            this.EditButton.AllowAnimations = true;
            this.EditButton.AllowMouseEffects = true;
            this.EditButton.AllowToggling = false;
            this.EditButton.AnimationSpeed = 200;
            this.EditButton.AutoGenerateColors = false;
            this.EditButton.AutoRoundBorders = false;
            this.EditButton.AutoSizeLeftIcon = true;
            this.EditButton.AutoSizeRightIcon = true;
            this.EditButton.BackColor = System.Drawing.Color.Transparent;
            this.EditButton.BackColor1 = System.Drawing.Color.DarkMagenta;
            this.EditButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EditButton.BackgroundImage")));
            this.EditButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EditButton.ButtonText = "Edit";
            this.EditButton.ButtonTextMarginLeft = 0;
            this.EditButton.ColorContrastOnClick = 45;
            this.EditButton.ColorContrastOnHover = 45;
            this.EditButton.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.EditButton.CustomizableEdges = borderEdges1;
            this.EditButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.EditButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.EditButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.EditButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.EditButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.EditButton.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditButton.ForeColor = System.Drawing.Color.White;
            this.EditButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.EditButton.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.EditButton.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.EditButton.IconMarginLeft = 11;
            this.EditButton.IconPadding = 10;
            this.EditButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.EditButton.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.EditButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.EditButton.IconSize = 25;
            this.EditButton.IdleBorderColor = System.Drawing.Color.DarkMagenta;
            this.EditButton.IdleBorderRadius = 7;
            this.EditButton.IdleBorderThickness = 1;
            this.EditButton.IdleFillColor = System.Drawing.Color.DarkMagenta;
            this.EditButton.IdleIconLeftImage = null;
            this.EditButton.IdleIconRightImage = null;
            this.EditButton.IndicateFocus = false;
            this.EditButton.Location = new System.Drawing.Point(98, 322);
            this.EditButton.Name = "EditButton";
            this.EditButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.EditButton.OnDisabledState.BorderRadius = 7;
            this.EditButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EditButton.OnDisabledState.BorderThickness = 1;
            this.EditButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.EditButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.EditButton.OnDisabledState.IconLeftImage = null;
            this.EditButton.OnDisabledState.IconRightImage = null;
            this.EditButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.EditButton.onHoverState.BorderRadius = 7;
            this.EditButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EditButton.onHoverState.BorderThickness = 1;
            this.EditButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.EditButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.EditButton.onHoverState.IconLeftImage = null;
            this.EditButton.onHoverState.IconRightImage = null;
            this.EditButton.OnIdleState.BorderColor = System.Drawing.Color.DarkMagenta;
            this.EditButton.OnIdleState.BorderRadius = 7;
            this.EditButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EditButton.OnIdleState.BorderThickness = 1;
            this.EditButton.OnIdleState.FillColor = System.Drawing.Color.DarkMagenta;
            this.EditButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.EditButton.OnIdleState.IconLeftImage = null;
            this.EditButton.OnIdleState.IconRightImage = null;
            this.EditButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.EditButton.OnPressedState.BorderRadius = 7;
            this.EditButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EditButton.OnPressedState.BorderThickness = 1;
            this.EditButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.EditButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.EditButton.OnPressedState.IconLeftImage = null;
            this.EditButton.OnPressedState.IconRightImage = null;
            this.EditButton.Size = new System.Drawing.Size(234, 39);
            this.EditButton.TabIndex = 5;
            this.EditButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.EditButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.EditButton.TextMarginLeft = 0;
            this.EditButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.EditButton.UseDefaultRadiusAndThickness = true;
            this.EditButton.Click += new System.EventHandler(this.EditButton_Click);
            // 
            // firstName_textbox
            // 
            this.firstName_textbox.AcceptsReturn = false;
            this.firstName_textbox.AcceptsTab = false;
            this.firstName_textbox.AnimationSpeed = 200;
            this.firstName_textbox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.firstName_textbox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.firstName_textbox.BackColor = System.Drawing.Color.White;
            this.firstName_textbox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("firstName_textbox.BackgroundImage")));
            this.firstName_textbox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.firstName_textbox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.firstName_textbox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.firstName_textbox.BorderColorIdle = System.Drawing.Color.Silver;
            this.firstName_textbox.BorderRadius = 10;
            this.firstName_textbox.BorderThickness = 1;
            this.firstName_textbox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.firstName_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.firstName_textbox.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstName_textbox.DefaultText = "";
            this.firstName_textbox.FillColor = System.Drawing.Color.White;
            this.firstName_textbox.ForeColor = System.Drawing.Color.DarkMagenta;
            this.firstName_textbox.HideSelection = true;
            this.firstName_textbox.IconLeft = null;
            this.firstName_textbox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.firstName_textbox.IconPadding = 10;
            this.firstName_textbox.IconRight = null;
            this.firstName_textbox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.firstName_textbox.Lines = new string[0];
            this.firstName_textbox.Location = new System.Drawing.Point(98, 58);
            this.firstName_textbox.MaxLength = 32767;
            this.firstName_textbox.MinimumSize = new System.Drawing.Size(1, 1);
            this.firstName_textbox.Modified = false;
            this.firstName_textbox.Multiline = false;
            this.firstName_textbox.Name = "firstName_textbox";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.firstName_textbox.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.firstName_textbox.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.firstName_textbox.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.DarkMagenta;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.firstName_textbox.OnIdleState = stateProperties16;
            this.firstName_textbox.Padding = new System.Windows.Forms.Padding(3);
            this.firstName_textbox.PasswordChar = '\0';
            this.firstName_textbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.firstName_textbox.PlaceholderText = "Enter User Name";
            this.firstName_textbox.ReadOnly = false;
            this.firstName_textbox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.firstName_textbox.SelectedText = "";
            this.firstName_textbox.SelectionLength = 0;
            this.firstName_textbox.SelectionStart = 0;
            this.firstName_textbox.ShortcutsEnabled = true;
            this.firstName_textbox.Size = new System.Drawing.Size(234, 31);
            this.firstName_textbox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.firstName_textbox.TabIndex = 0;
            this.firstName_textbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.firstName_textbox.TextMarginBottom = 0;
            this.firstName_textbox.TextMarginLeft = 3;
            this.firstName_textbox.TextMarginTop = 0;
            this.firstName_textbox.TextPlaceholder = "Enter User Name";
            this.firstName_textbox.UseSystemPasswordChar = false;
            this.firstName_textbox.WordWrap = true;
            this.firstName_textbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.firstName_textbox_KeyDown);
            // 
            // LogInFormEllips
            // 
            this.LogInFormEllips.ElipseRadius = 10;
            this.LogInFormEllips.TargetControl = this;
            // 
            // Exit
            // 
            this.Exit.ActiveImage = ((System.Drawing.Image)(resources.GetObject("Exit.ActiveImage")));
            this.Exit.AllowAnimations = true;
            this.Exit.AllowBuffering = false;
            this.Exit.AllowToggling = false;
            this.Exit.AllowZooming = true;
            this.Exit.AllowZoomingOnFocus = true;
            this.Exit.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Exit.AutoScrollMargin = new System.Drawing.Size(800, 450);
            this.Exit.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.Exit.BackColor = System.Drawing.Color.Transparent;
            this.Exit.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Exit.ErrorImage = ((System.Drawing.Image)(resources.GetObject("Exit.ErrorImage")));
            this.Exit.FadeWhenInactive = false;
            this.Exit.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.Exit.Image = ((System.Drawing.Image)(resources.GetObject("Exit.Image")));
            this.Exit.ImageActive = ((System.Drawing.Image)(resources.GetObject("Exit.ImageActive")));
            this.Exit.ImageLocation = null;
            this.Exit.ImageMargin = 40;
            this.Exit.ImageSize = new System.Drawing.Size(-40, -40);
            this.Exit.ImageZoomSize = new System.Drawing.Size(0, 0);
            this.Exit.InitialImage = ((System.Drawing.Image)(resources.GetObject("Exit.InitialImage")));
            this.Exit.Location = new System.Drawing.Point(22, 18);
            this.Exit.Name = "Exit";
            this.Exit.Rotation = 0;
            this.Exit.ShowActiveImage = true;
            this.Exit.ShowCursorChanges = true;
            this.Exit.ShowImageBorders = true;
            this.Exit.ShowSizeMarkers = false;
            this.Exit.Size = new System.Drawing.Size(0, 0);
            this.Exit.TabIndex = 0;
            this.Exit.ToolTipText = "";
            this.Exit.WaitOnLoad = false;
            this.Exit.Zoom = 40;
            this.Exit.ZoomSpeed = 10;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Customer_Edit_Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkMagenta;
            this.ClientSize = new System.Drawing.Size(439, 468);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Exit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Customer_Edit_Profile";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "0";
            this.Load += new System.EventHandler(this.Customer_Edit_Profile_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuElipse LogInFormEllips;
        private Bunifu.UI.WinForms.BunifuImageButton Exit;
        private Bunifu.UI.WinForms.BunifuTextBox phone_textbox;
        private Bunifu.UI.WinForms.BunifuTextBox email_textbox;
        private System.Windows.Forms.Label Logo;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton EditButton;
        private Bunifu.UI.WinForms.BunifuTextBox firstName_textbox;
        private System.Windows.Forms.Label emailErr;
        private System.Windows.Forms.Label firstNameErr;
        private System.Windows.Forms.Label phoneErr;
        private System.Windows.Forms.Label ID_label;
        private System.Windows.Forms.Label lastNameErr;
        private Bunifu.UI.WinForms.BunifuTextBox lastName_textBox;
        private System.Windows.Forms.Label dobErr;
        private System.Windows.Forms.DateTimePicker dobDatePicker;
    }
}