﻿
namespace WholeSaleManagementSystem
{
    partial class Customer_Change_Password
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customer_Change_Password));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cpasswordErr = new System.Windows.Forms.Label();
            this.passwordErr = new System.Windows.Forms.Label();
            this.cpassword_textbox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.password_textbox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.ID_label = new System.Windows.Forms.Label();
            this.Logo = new System.Windows.Forms.Label();
            this.changePasswordButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.LogInFormEllips = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.Exit = new Bunifu.UI.WinForms.BunifuImageButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.oldPasswordTextBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.oldPasswordErr = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.oldPasswordErr);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.oldPasswordTextBox);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.cpasswordErr);
            this.panel1.Controls.Add(this.passwordErr);
            this.panel1.Controls.Add(this.cpassword_textbox);
            this.panel1.Controls.Add(this.password_textbox);
            this.panel1.Controls.Add(this.ID_label);
            this.panel1.Controls.Add(this.Logo);
            this.panel1.Controls.Add(this.changePasswordButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(10, 10);
            this.panel1.Margin = new System.Windows.Forms.Padding(10);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(15);
            this.panel1.Size = new System.Drawing.Size(419, 448);
            this.panel1.TabIndex = 1;
            // 
            // cpasswordErr
            // 
            this.cpasswordErr.AutoSize = true;
            this.cpasswordErr.ForeColor = System.Drawing.Color.Red;
            this.cpasswordErr.Location = new System.Drawing.Point(107, 313);
            this.cpasswordErr.Name = "cpasswordErr";
            this.cpasswordErr.Size = new System.Drawing.Size(0, 13);
            this.cpasswordErr.TabIndex = 20;
            // 
            // passwordErr
            // 
            this.passwordErr.AutoSize = true;
            this.passwordErr.ForeColor = System.Drawing.Color.Red;
            this.passwordErr.Location = new System.Drawing.Point(107, 263);
            this.passwordErr.Name = "passwordErr";
            this.passwordErr.Size = new System.Drawing.Size(0, 13);
            this.passwordErr.TabIndex = 19;
            // 
            // cpassword_textbox
            // 
            this.cpassword_textbox.AcceptsReturn = false;
            this.cpassword_textbox.AcceptsTab = false;
            this.cpassword_textbox.AnimationSpeed = 200;
            this.cpassword_textbox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.cpassword_textbox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.cpassword_textbox.BackColor = System.Drawing.Color.White;
            this.cpassword_textbox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cpassword_textbox.BackgroundImage")));
            this.cpassword_textbox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.cpassword_textbox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cpassword_textbox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.cpassword_textbox.BorderColorIdle = System.Drawing.Color.Silver;
            this.cpassword_textbox.BorderRadius = 10;
            this.cpassword_textbox.BorderThickness = 1;
            this.cpassword_textbox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.cpassword_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cpassword_textbox.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpassword_textbox.DefaultText = "";
            this.cpassword_textbox.FillColor = System.Drawing.Color.White;
            this.cpassword_textbox.ForeColor = System.Drawing.Color.DarkMagenta;
            this.cpassword_textbox.HideSelection = true;
            this.cpassword_textbox.IconLeft = null;
            this.cpassword_textbox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.cpassword_textbox.IconPadding = 10;
            this.cpassword_textbox.IconRight = null;
            this.cpassword_textbox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.cpassword_textbox.Lines = new string[0];
            this.cpassword_textbox.Location = new System.Drawing.Point(89, 279);
            this.cpassword_textbox.MaxLength = 32767;
            this.cpassword_textbox.MinimumSize = new System.Drawing.Size(1, 1);
            this.cpassword_textbox.Modified = false;
            this.cpassword_textbox.Multiline = false;
            this.cpassword_textbox.Name = "cpassword_textbox";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.cpassword_textbox.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.cpassword_textbox.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.cpassword_textbox.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.DarkMagenta;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.cpassword_textbox.OnIdleState = stateProperties8;
            this.cpassword_textbox.Padding = new System.Windows.Forms.Padding(3);
            this.cpassword_textbox.PasswordChar = '●';
            this.cpassword_textbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.cpassword_textbox.PlaceholderText = "Confirm Passowrd";
            this.cpassword_textbox.ReadOnly = false;
            this.cpassword_textbox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.cpassword_textbox.SelectedText = "";
            this.cpassword_textbox.SelectionLength = 0;
            this.cpassword_textbox.SelectionStart = 0;
            this.cpassword_textbox.ShortcutsEnabled = true;
            this.cpassword_textbox.Size = new System.Drawing.Size(234, 31);
            this.cpassword_textbox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.cpassword_textbox.TabIndex = 18;
            this.cpassword_textbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.cpassword_textbox.TextMarginBottom = 0;
            this.cpassword_textbox.TextMarginLeft = 3;
            this.cpassword_textbox.TextMarginTop = 0;
            this.cpassword_textbox.TextPlaceholder = "Confirm Passowrd";
            this.cpassword_textbox.UseSystemPasswordChar = true;
            this.cpassword_textbox.WordWrap = true;
            this.cpassword_textbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cpassword_textbox_KeyDown);
            // 
            // password_textbox
            // 
            this.password_textbox.AcceptsReturn = false;
            this.password_textbox.AcceptsTab = false;
            this.password_textbox.AnimationSpeed = 200;
            this.password_textbox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.password_textbox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.password_textbox.BackColor = System.Drawing.Color.White;
            this.password_textbox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("password_textbox.BackgroundImage")));
            this.password_textbox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.password_textbox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.password_textbox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.password_textbox.BorderColorIdle = System.Drawing.Color.Silver;
            this.password_textbox.BorderRadius = 10;
            this.password_textbox.BorderThickness = 1;
            this.password_textbox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.password_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.password_textbox.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_textbox.DefaultText = "";
            this.password_textbox.FillColor = System.Drawing.Color.White;
            this.password_textbox.ForeColor = System.Drawing.Color.DarkMagenta;
            this.password_textbox.HideSelection = true;
            this.password_textbox.IconLeft = null;
            this.password_textbox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.password_textbox.IconPadding = 10;
            this.password_textbox.IconRight = null;
            this.password_textbox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.password_textbox.Lines = new string[0];
            this.password_textbox.Location = new System.Drawing.Point(89, 229);
            this.password_textbox.MaxLength = 32767;
            this.password_textbox.MinimumSize = new System.Drawing.Size(1, 1);
            this.password_textbox.Modified = false;
            this.password_textbox.Multiline = false;
            this.password_textbox.Name = "password_textbox";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.password_textbox.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.password_textbox.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.password_textbox.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.DarkMagenta;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.password_textbox.OnIdleState = stateProperties12;
            this.password_textbox.Padding = new System.Windows.Forms.Padding(3);
            this.password_textbox.PasswordChar = '●';
            this.password_textbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.password_textbox.PlaceholderText = "Enter Pasword";
            this.password_textbox.ReadOnly = false;
            this.password_textbox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.password_textbox.SelectedText = "";
            this.password_textbox.SelectionLength = 0;
            this.password_textbox.SelectionStart = 0;
            this.password_textbox.ShortcutsEnabled = true;
            this.password_textbox.Size = new System.Drawing.Size(234, 31);
            this.password_textbox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.password_textbox.TabIndex = 17;
            this.password_textbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.password_textbox.TextMarginBottom = 0;
            this.password_textbox.TextMarginLeft = 3;
            this.password_textbox.TextMarginTop = 0;
            this.password_textbox.TextPlaceholder = "Enter Pasword";
            this.password_textbox.UseSystemPasswordChar = true;
            this.password_textbox.WordWrap = true;
            this.password_textbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.password_textbox_KeyDown);
            // 
            // ID_label
            // 
            this.ID_label.AutoSize = true;
            this.ID_label.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.ID_label.ForeColor = System.Drawing.Color.DarkMagenta;
            this.ID_label.Location = new System.Drawing.Point(217, 67);
            this.ID_label.Name = "ID_label";
            this.ID_label.Size = new System.Drawing.Size(21, 23);
            this.ID_label.TabIndex = 14;
            this.ID_label.Text = "?";
            // 
            // Logo
            // 
            this.Logo.AutoSize = true;
            this.Logo.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.Logo.ForeColor = System.Drawing.Color.DarkMagenta;
            this.Logo.Location = new System.Drawing.Point(174, 67);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(33, 23);
            this.Logo.TabIndex = 10;
            this.Logo.Text = "ID:";
            // 
            // changePasswordButton
            // 
            this.changePasswordButton.AllowAnimations = true;
            this.changePasswordButton.AllowMouseEffects = true;
            this.changePasswordButton.AllowToggling = false;
            this.changePasswordButton.AnimationSpeed = 200;
            this.changePasswordButton.AutoGenerateColors = false;
            this.changePasswordButton.AutoRoundBorders = false;
            this.changePasswordButton.AutoSizeLeftIcon = true;
            this.changePasswordButton.AutoSizeRightIcon = true;
            this.changePasswordButton.BackColor = System.Drawing.Color.Transparent;
            this.changePasswordButton.BackColor1 = System.Drawing.Color.DarkMagenta;
            this.changePasswordButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("changePasswordButton.BackgroundImage")));
            this.changePasswordButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.changePasswordButton.ButtonText = "Change Password";
            this.changePasswordButton.ButtonTextMarginLeft = 0;
            this.changePasswordButton.ColorContrastOnClick = 45;
            this.changePasswordButton.ColorContrastOnHover = 45;
            this.changePasswordButton.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.changePasswordButton.CustomizableEdges = borderEdges1;
            this.changePasswordButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.changePasswordButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.changePasswordButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.changePasswordButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.changePasswordButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.changePasswordButton.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changePasswordButton.ForeColor = System.Drawing.Color.White;
            this.changePasswordButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.changePasswordButton.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.changePasswordButton.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.changePasswordButton.IconMarginLeft = 11;
            this.changePasswordButton.IconPadding = 10;
            this.changePasswordButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.changePasswordButton.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.changePasswordButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.changePasswordButton.IconSize = 25;
            this.changePasswordButton.IdleBorderColor = System.Drawing.Color.DarkMagenta;
            this.changePasswordButton.IdleBorderRadius = 7;
            this.changePasswordButton.IdleBorderThickness = 1;
            this.changePasswordButton.IdleFillColor = System.Drawing.Color.DarkMagenta;
            this.changePasswordButton.IdleIconLeftImage = null;
            this.changePasswordButton.IdleIconRightImage = null;
            this.changePasswordButton.IndicateFocus = false;
            this.changePasswordButton.Location = new System.Drawing.Point(91, 329);
            this.changePasswordButton.Name = "changePasswordButton";
            this.changePasswordButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.changePasswordButton.OnDisabledState.BorderRadius = 7;
            this.changePasswordButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.changePasswordButton.OnDisabledState.BorderThickness = 1;
            this.changePasswordButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.changePasswordButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.changePasswordButton.OnDisabledState.IconLeftImage = null;
            this.changePasswordButton.OnDisabledState.IconRightImage = null;
            this.changePasswordButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.changePasswordButton.onHoverState.BorderRadius = 7;
            this.changePasswordButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.changePasswordButton.onHoverState.BorderThickness = 1;
            this.changePasswordButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.changePasswordButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.changePasswordButton.onHoverState.IconLeftImage = null;
            this.changePasswordButton.onHoverState.IconRightImage = null;
            this.changePasswordButton.OnIdleState.BorderColor = System.Drawing.Color.DarkMagenta;
            this.changePasswordButton.OnIdleState.BorderRadius = 7;
            this.changePasswordButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.changePasswordButton.OnIdleState.BorderThickness = 1;
            this.changePasswordButton.OnIdleState.FillColor = System.Drawing.Color.DarkMagenta;
            this.changePasswordButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.changePasswordButton.OnIdleState.IconLeftImage = null;
            this.changePasswordButton.OnIdleState.IconRightImage = null;
            this.changePasswordButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.changePasswordButton.OnPressedState.BorderRadius = 7;
            this.changePasswordButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.changePasswordButton.OnPressedState.BorderThickness = 1;
            this.changePasswordButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.changePasswordButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.changePasswordButton.OnPressedState.IconLeftImage = null;
            this.changePasswordButton.OnPressedState.IconRightImage = null;
            this.changePasswordButton.Size = new System.Drawing.Size(234, 39);
            this.changePasswordButton.TabIndex = 6;
            this.changePasswordButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.changePasswordButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.changePasswordButton.TextMarginLeft = 0;
            this.changePasswordButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.changePasswordButton.UseDefaultRadiusAndThickness = true;
            this.changePasswordButton.Click += new System.EventHandler(this.changePasswordButton_Click);
            // 
            // LogInFormEllips
            // 
            this.LogInFormEllips.ElipseRadius = 10;
            this.LogInFormEllips.TargetControl = this;
            // 
            // Exit
            // 
            this.Exit.ActiveImage = ((System.Drawing.Image)(resources.GetObject("Exit.ActiveImage")));
            this.Exit.AllowAnimations = true;
            this.Exit.AllowBuffering = false;
            this.Exit.AllowToggling = false;
            this.Exit.AllowZooming = true;
            this.Exit.AllowZoomingOnFocus = true;
            this.Exit.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Exit.AutoScrollMargin = new System.Drawing.Size(800, 450);
            this.Exit.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.Exit.BackColor = System.Drawing.Color.Transparent;
            this.Exit.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Exit.ErrorImage = ((System.Drawing.Image)(resources.GetObject("Exit.ErrorImage")));
            this.Exit.FadeWhenInactive = false;
            this.Exit.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.Exit.Image = ((System.Drawing.Image)(resources.GetObject("Exit.Image")));
            this.Exit.ImageActive = ((System.Drawing.Image)(resources.GetObject("Exit.ImageActive")));
            this.Exit.ImageLocation = null;
            this.Exit.ImageMargin = 40;
            this.Exit.ImageSize = new System.Drawing.Size(-40, -40);
            this.Exit.ImageZoomSize = new System.Drawing.Size(0, 0);
            this.Exit.InitialImage = ((System.Drawing.Image)(resources.GetObject("Exit.InitialImage")));
            this.Exit.Location = new System.Drawing.Point(22, 18);
            this.Exit.Name = "Exit";
            this.Exit.Rotation = 0;
            this.Exit.ShowActiveImage = true;
            this.Exit.ShowCursorChanges = true;
            this.Exit.ShowImageBorders = true;
            this.Exit.ShowSizeMarkers = false;
            this.Exit.Size = new System.Drawing.Size(0, 0);
            this.Exit.TabIndex = 0;
            this.Exit.ToolTipText = "";
            this.Exit.WaitOnLoad = false;
            this.Exit.Zoom = 40;
            this.Exit.ZoomSpeed = 10;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label1.Location = new System.Drawing.Point(96, 203);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 23);
            this.label1.TabIndex = 21;
            this.label1.Text = "New Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label2.Location = new System.Drawing.Point(97, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 23);
            this.label2.TabIndex = 23;
            this.label2.Text = "Old Password";
            // 
            // oldPasswordTextBox
            // 
            this.oldPasswordTextBox.AcceptsReturn = false;
            this.oldPasswordTextBox.AcceptsTab = false;
            this.oldPasswordTextBox.AnimationSpeed = 200;
            this.oldPasswordTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.oldPasswordTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.oldPasswordTextBox.BackColor = System.Drawing.Color.White;
            this.oldPasswordTextBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("oldPasswordTextBox.BackgroundImage")));
            this.oldPasswordTextBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.oldPasswordTextBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.oldPasswordTextBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.oldPasswordTextBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.oldPasswordTextBox.BorderRadius = 10;
            this.oldPasswordTextBox.BorderThickness = 1;
            this.oldPasswordTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.oldPasswordTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.oldPasswordTextBox.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oldPasswordTextBox.DefaultText = "";
            this.oldPasswordTextBox.FillColor = System.Drawing.Color.White;
            this.oldPasswordTextBox.ForeColor = System.Drawing.Color.DarkMagenta;
            this.oldPasswordTextBox.HideSelection = true;
            this.oldPasswordTextBox.IconLeft = null;
            this.oldPasswordTextBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.oldPasswordTextBox.IconPadding = 10;
            this.oldPasswordTextBox.IconRight = null;
            this.oldPasswordTextBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.oldPasswordTextBox.Lines = new string[0];
            this.oldPasswordTextBox.Location = new System.Drawing.Point(90, 141);
            this.oldPasswordTextBox.MaxLength = 32767;
            this.oldPasswordTextBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.oldPasswordTextBox.Modified = false;
            this.oldPasswordTextBox.Multiline = false;
            this.oldPasswordTextBox.Name = "oldPasswordTextBox";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.oldPasswordTextBox.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.oldPasswordTextBox.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.oldPasswordTextBox.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.DarkMagenta;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.oldPasswordTextBox.OnIdleState = stateProperties4;
            this.oldPasswordTextBox.Padding = new System.Windows.Forms.Padding(3);
            this.oldPasswordTextBox.PasswordChar = '●';
            this.oldPasswordTextBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.oldPasswordTextBox.PlaceholderText = "Enter Pasword";
            this.oldPasswordTextBox.ReadOnly = false;
            this.oldPasswordTextBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.oldPasswordTextBox.SelectedText = "";
            this.oldPasswordTextBox.SelectionLength = 0;
            this.oldPasswordTextBox.SelectionStart = 0;
            this.oldPasswordTextBox.ShortcutsEnabled = true;
            this.oldPasswordTextBox.Size = new System.Drawing.Size(234, 31);
            this.oldPasswordTextBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.oldPasswordTextBox.TabIndex = 22;
            this.oldPasswordTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.oldPasswordTextBox.TextMarginBottom = 0;
            this.oldPasswordTextBox.TextMarginLeft = 3;
            this.oldPasswordTextBox.TextMarginTop = 0;
            this.oldPasswordTextBox.TextPlaceholder = "Enter Pasword";
            this.oldPasswordTextBox.UseSystemPasswordChar = true;
            this.oldPasswordTextBox.WordWrap = true;
            this.oldPasswordTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.oldPasswordTextBox_KeyDown);
            // 
            // oldPasswordErr
            // 
            this.oldPasswordErr.AutoSize = true;
            this.oldPasswordErr.ForeColor = System.Drawing.Color.Red;
            this.oldPasswordErr.Location = new System.Drawing.Point(107, 175);
            this.oldPasswordErr.Name = "oldPasswordErr";
            this.oldPasswordErr.Size = new System.Drawing.Size(0, 13);
            this.oldPasswordErr.TabIndex = 24;
            // 
            // Customer_Change_Password
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkMagenta;
            this.ClientSize = new System.Drawing.Size(439, 468);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Exit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Customer_Change_Password";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "0";
            this.Load += new System.EventHandler(this.Customer_Change_Password_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuElipse LogInFormEllips;
        private Bunifu.UI.WinForms.BunifuImageButton Exit;
        private System.Windows.Forms.Label Logo;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton changePasswordButton;
        private System.Windows.Forms.Label ID_label;
        private System.Windows.Forms.Label cpasswordErr;
        private System.Windows.Forms.Label passwordErr;
        private Bunifu.UI.WinForms.BunifuTextBox cpassword_textbox;
        private Bunifu.UI.WinForms.BunifuTextBox password_textbox;
        private System.Windows.Forms.Label oldPasswordErr;
        private System.Windows.Forms.Label label2;
        private Bunifu.UI.WinForms.BunifuTextBox oldPasswordTextBox;
        private System.Windows.Forms.Label label1;
    }
}